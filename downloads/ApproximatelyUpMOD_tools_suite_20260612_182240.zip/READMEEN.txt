﻿ApproximatelyUpMOD tools suite

What it is:
A main utility menu for Approximately Up. It includes service tools, safety settings, gameplay tweaks, and extra buttons.

Installation:
1. Install MelonLoader for Approximately Up.
2. Open the game folder.
3. Put ApproximatelyUpMOD.dll into the Mods folder.
4. Start the game.
5. Open the mod menu in game using the hotkey shown by the mod or in the MelonLoader logs.

Important:
After Approximately Up updates, some features can break temporarily. If the game crashes or the menu does not appear, check MelonLoader logs and the game version.

Status:
Marked as "Check" because the mod depends on game updates.
