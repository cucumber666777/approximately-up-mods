﻿Planet Runtime Editor v0.8.5

What it is:
A runtime editor for planets and objects in Approximately Up. It can edit coordinates, radius, gravity, atmosphere color, water color, cloud color, surface color, star color, and host-only multiplayer synchronization.

Installation:
1. Install MelonLoader for Approximately Up.
2. Open the game folder.
3. Put PlanetRuntimeEditor.dll into the Mods folder.
4. Start the game.
5. Press F11 in game to open the editor menu.

Multiplayer sync:
1. Every player must have this exact mod installed.
2. The host opens F11, chooses Host, and clicks Start host sync.
3. A client opens F11, chooses Client, enters the host IP, and clicks Connect client.
4. The host edits objects, clients mirror the changes.

Status:
Marked as "Check" because game updates can require retesting the mod.
